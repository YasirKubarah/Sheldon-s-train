/**
 * Train Collision Exception is raised when train collusion detected
 */
public class TrainCollisionException extends Exception {
}
