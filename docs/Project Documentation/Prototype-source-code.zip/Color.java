/**
 * This enum holds the possible colors for the PassangerCar and Stations classes.
 */
public enum Color {
    RED, PINK, GREEN, ORANGE, BLUE, YELLOW
}
