/**
 * Color Mismatch Exception is raised when PassengerCar color and Station color do not match.
 */
public class ColorMismatchException extends Exception {
}
