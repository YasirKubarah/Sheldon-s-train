/**
 * Train Collision Exception
 */
public class TrainCollisionException extends Exception {
}
