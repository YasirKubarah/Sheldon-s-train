/**
 * Color Mismatch Exception
 */
public class ColorMismatchException extends Exception {
}
