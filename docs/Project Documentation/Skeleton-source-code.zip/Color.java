/**
 * This enum holds the possible colors for the PassangerCar and Stations.
 */
public enum Color {
    RED, PINK, GREEN, ORANGE, BLUE, YELLOW
}
