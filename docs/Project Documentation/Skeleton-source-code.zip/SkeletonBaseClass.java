/**
 * Stage class is utility class to store variable name.
 */
public class SkeletonBaseClass {
    protected String variableName;
    /**
     * This method is constructor
     *
     * @param variableName String
     */
    public SkeletonBaseClass(String variableName) {
        this.variableName = variableName;
    }
}

